$('.new').click(function(){
    window.location.href = '/novo';
});