$("#busca").keyup(function(){
    $.get('/busca?logradouro='+$("#busca").val(), function(data){
        if($("#busca").val() == "")
            $('#resultBusca').html('');
        else
            $('#resultBusca').html(data);
    });
});