<?php

namespace App\Http\Controllers;

use Request;
use App\Endereco;

class EnderecoController extends Controller{
    //Lista todos os endereços cadastrados
    public function lista(){
        $enderecos = Endereco::all();
        return view("listagem")->with('enderecos', $enderecos);
    }

    //Apenas retorna a view onde o usuário podera cadastrar um novo endereço
    public function novo(){
        return view("novo");
    }

    //Mostra a lista de endereços cadastrados de acordo com o que foi digitado na busca
    public function busca(){
        $endereco = new Endereco();
        $data = $endereco->where('logradouro', 'LIKE', '%'.Request::get('logradouro').'%')->get();
        $rua = json_decode($data);
        return view('lista_endereco')->with('rua', $rua);
    }

    //Mostra o endereço escolhido pelo usuário
    public function endereco($id){
        $enderecos = Endereco::find($id);
        return view("detalhes")->with('enderecos', $enderecos);
    }

    //Adiciona um novo endereço no banco de dados
    public function adicionar(){
        $endereco = new Endereco();
        $endereco->logradouro = Request::input('logradouro');
        $endereco->complemento = Request::input('complemento');
        $endereco->bairro = Request::input('bairro');
        $endereco->cidade = Request::input('cidade');
        $endereco->uf = Request::input('uf');
        $endereco->cep = Request::input('cep');
        $endereco->save();
        return redirect()->action('EnderecoController@lista');
    }
}
