@extends("principal")

@section("content")
<br>
<div class='container'>
    <form class='form' method='post' action='/adicionar'>
    <input type="hidden" name="_token" value="{{{ csrf_token() }}}" />
        <div class='form-group'>
            CEP:
            <input class="form-control" placeholder="CEP" name='cep' id='cep'/>
        </div>
        <div class='form-group'>
            Logradouro:
            <input class="form-control" placeholder="Logradouro" name='logradouro' id='rua'/>
        </div>
        <div class='form-group'>
            Complemento:
            <input class="form-control" placeholder="Complemento" name='complemento' id='complemento'/>
        </div>
        <div class='form-group'>
            Bairro:
            <input class="form-control" placeholder="Bairro" name='bairro' id='bairro'/>
        </div>
        <div class='form-group'>
            Cidade:
            <input class="form-control" placeholder="Cidade" name='cidade' id='cidade'/>
        </div>
        <div class='form-group'>
            UF:
            <input class="form-control" placeholder="UF" name='uf' id='uf'/>
        </div>
        <button class='btn btn-primary'>Adicionar</button>
    </form>
</div>
@stop