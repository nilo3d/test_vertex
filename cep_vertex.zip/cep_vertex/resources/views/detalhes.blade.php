@extends("principal")

@section("content")
<br>
    Busca:<br>
    <div class='header'>
        <input class='input-find' placeholder="Digite um logradouro..." name='busca' id='busca'>
        <div id='resultBusca'></div>
    </div>
    <br>
    <div class='board'>
        <div class='endereco'>
            <p class = 'nome-rua'>Logradouro: {{$enderecos->logradouro}}</p>
            <div class='sub-line'></div>
            <p class = 'nome-complemento'>Complemento: {{$enderecos->complemento}}</p>
            <p class = 'nome-bairro'>Bairro: {{$enderecos->bairro}}</p>
            <p class = 'nome-cidade'>Cidade: {{$enderecos->cidade}}</p>
            <p class = 'nome-uf'>UF: {{$enderecos->uf}}</p>
            <p class = 'nome-cep'>CEP: {{$enderecos->cep}}</p>
        </div> 
    </div>
    <a href="https://www.google.com/maps/search/{{$enderecos->cep}}" target="_blank">Ver no mapa</a>
@stop