<ul>
    @foreach($rua as $r)
        <a href="/endereco/{{$r->id}}"><li>{{$r->logradouro}}</li></a>
    @endforeach
</ul>