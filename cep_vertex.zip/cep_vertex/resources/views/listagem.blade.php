@extends("principal")

@section("content")
<br>
    Busca:<br>
    <div class='header'>
        <input class='input-find' placeholder="Digite um logradouro..." name='busca' id='busca'>
        <div id='resultBusca'></div>
    </div>
    <br>
    <div class='board'>
    <div class='new' title='adicionar novo'>+</div>
        @foreach($enderecos as $e)
        <div class='endereco'>
            <p class = 'nome-rua'>Logradouro: {{$e->logradouro}}</p>
            <div class='sub-line'></div>
            <p class = 'nome-complemento'>Complemento: {{$e->complemento}}</p>
            <p class = 'nome-bairro'>Bairro: {{$e->bairro}}</p>
            <p class = 'nome-cidade'>Cidade: {{$e->cidade}}</p>
            <p class = 'nome-uf'>UF: {{$e->uf}}</p>
            <p class = 'nome-cep'>CEP: {{$e->cep}}</p>
        </div> 
        @endforeach
    </div>
@stop