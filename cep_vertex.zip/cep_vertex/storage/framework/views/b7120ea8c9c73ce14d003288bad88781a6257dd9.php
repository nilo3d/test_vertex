<ul>
    <?php $__currentLoopData = $rua; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="/endereco/<?php echo e($r->id); ?>"><li><?php echo e($r->logradouro); ?></li></a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>