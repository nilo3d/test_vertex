<?php $__env->startSection("content"); ?>
<br>
    Busca:<br>
    <div class='header'>
        <input class='input-find' placeholder="Digite um logradouro..." name='busca' id='busca'>
        <div id='resultBusca'></div>
    </div>
    <br>
    <div class='board'>
    <div class='new' title='adicionar novo'>+</div>
        <?php $__currentLoopData = $enderecos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class='endereco'>
            <p class = 'nome-rua'>Logradouro: <?php echo e($e->logradouro); ?></p>
            <div class='sub-line'></div>
            <p class = 'nome-complemento'>Complemento: <?php echo e($e->complemento); ?></p>
            <p class = 'nome-bairro'>Bairro: <?php echo e($e->bairro); ?></p>
            <p class = 'nome-cidade'>Cidade: <?php echo e($e->cidade); ?></p>
            <p class = 'nome-uf'>UF: <?php echo e($e->uf); ?></p>
            <p class = 'nome-cep'>CEP: <?php echo e($e->cep); ?></p>
        </div> 
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("principal", \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>