<!doctype html>
<html>
    <head>
        <title>Test</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" type="text/css" href="/css/app.css">
        <link rel="stylesheet" type="text/css" href="/css/style.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    </head>
    <body>
        <nav class='menu'>
            <div class='title'>
                <div class='option'>CEP</div>
            </div>
            <div class='sub-menu'>
                <div class='option'><a href='/novo'>NOVO</a></div>
                <div class='option'><a href='/'>LISTAGEM</a></div>
            </div>
        </nav>
        <div class='centralize'>
            <?php echo $__env->yieldContent("content"); ?>
        </div>
        <script src='/js/cep.js'></script>
        <script src='/js/filtro.js'></script>
        <script src='/js/novo.js'></script>
    </body>
</html>