<?php $__env->startSection("content"); ?>
<br>
    Busca:<br>
    <div class='header'>
        <input class='input-find' placeholder="Digite um logradouro..." name='busca' id='busca'>
        <div id='resultBusca'></div>
    </div>
    <br>
    <div class='board'>
        <div class='endereco'>
            <p class = 'nome-rua'>Logradouro: <?php echo e($enderecos->logradouro); ?></p>
            <div class='sub-line'></div>
            <p class = 'nome-complemento'>Complemento: <?php echo e($enderecos->complemento); ?></p>
            <p class = 'nome-bairro'>Bairro: <?php echo e($enderecos->bairro); ?></p>
            <p class = 'nome-cidade'>Cidade: <?php echo e($enderecos->cidade); ?></p>
            <p class = 'nome-uf'>UF: <?php echo e($enderecos->uf); ?></p>
            <p class = 'nome-cep'>CEP: <?php echo e($enderecos->cep); ?></p>
        </div> 
    </div>
    <a href="https://www.google.com/maps/search/<?php echo e($enderecos->cep); ?>" target="_blank">Ver no mapa</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("principal", \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>