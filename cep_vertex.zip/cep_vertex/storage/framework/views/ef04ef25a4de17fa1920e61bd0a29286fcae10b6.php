<?php $__env->startSection("content"); ?>
<br>
<div class='container'>
    <form class='form' method='post'>
        <div class='form-group'>
            CEP:
            <input class="form-control" placeholder="CEP" name='cep'/>
        </div>
        <div class='form-group'>
            Logradouro:
            <input class="form-control" placeholder="Logradouro" name='logradouro'/>
        </div>
        <div class='form-group'>
            Complemento:
            <input class="form-control" placeholder="Complemento" name='complemento'/>
        </div>
        <div class='form-group'>
            Cidade:
            <input class="form-control" placeholder="Cidade" name='cidade'/>
        </div>
        <div class='form-group'>
            UF:
            <input class="form-control" placeholder="UF" name='uf'/>
        </div>
        <button class='btn btn-primary'>Adicionar</button>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("principal", \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>