<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

//Página principal: busca e lista os endereços
Route::get('/', 'EnderecoController@lista');

//Usuário cria novo endereço
Route::get('/novo', 'EnderecoController@novo');

//Adiciona endereço ao banco de dados
Route::post('/adicionar', 'EnderecoController@adicionar');

Route::get('/busca', 'EnderecoController@busca');

Route::get('/endereco/{id}', 'EnderecoController@endereco');
