# cep_vertex
